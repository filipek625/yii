<?php

/** @var yii\web\View $this */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron text-center bg-transparent mt-5 mb-5">
        <h1 class="display-4">Ocice - Moja Wieś!</h1>

        <p class="lead">Ocice to dzielnica raciborza położona w jego zachodniej części. Na mojej stronce chciałbym przybliżyć po krótce historię tego miejsca oraz legendy które dotyczą ocic</p>

        <p><a class="btn btn-lg btn-success" href="https://www.yiiframework.com">Get started with Yii</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4 mb-3">
                <h2>Legenda 1</h2>

                <p>Legenda ta dotyczy miejsca na zdjeciu poniżej, a mianowicie młodsze pokolenie mieszkańców myślało ze jest to bunkier który jest pozostałością po 2wś. Myślano również że bunkier jest zamieszkiwany przez duchy żołnierzy które to miały pokazywać się w halloween o północy, urządzano nawet polowania na nie ale nigdy owych duchów nie znaleziono. Niestety wiarygodność legendy została rozwiana przez najstarszych mieszkańców ocic którzy zdradzili prawde na temat tego miejsca. "Budynek" nie ma nic wspólnego z bunkrem, najzwyczajniej w świecie była to pieczarkarnia.</p>

                <p><a class="btn btn-outline-secondary" href="https://www.yiiframework.com/doc/">Yii Documentation &raquo;</a></p>
            </div>
            <div class="col-lg-4 mb-3">
                <h2>Legenda 2</h2>

                <p>Według dawnych przekazów i miejscowych legend, to właśnie na terenie dzisiejszych Ocic miał znajdować się niegdyś potężny zamek, w którym rezydowali ojcowie książąt raciborskich. Było to miejsce o dużym znaczeniu, zarówno strategicznym, jak i symbolicznym, stanowiące centrum życia rodowego i politycznego ówczesnych władców tych ziem. Zamek ten miał być świadkiem wielu ważnych wydarzeń i decyzji, które wpływały na losy całego regionu. Z tego względu nazwa dzielnicy – Ocice – wywodzi się od starosłowiańskiego słowa „Oteć”, oznaczającego „ojca”.</p>
                <p><a class="btn btn-outline-secondary" href="https://www.yiiframework.com/forum/">Yii Forum &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Legenda 3</h2>

                <p>Ostatnia legenda dotyczy tzw. "psychola z ocic" który miał żyć w kanałach ulicy Francuskiej. Miał on porywać mieszkańców powodzian którzy nie należeli do najgrzeczniejszych. Psycholem mial być starszy pan który nie potrafił pogodzić sie z faktem, iż na ziemi która należała niegdyś do jego rodziny zbudowano wcześniej wspomniane osiedle dla powodzian nazywane "polskim Harlemem" ze względu właśnie na mieszkańcow. Jak mozna sie domyślić autorami legendy byli bogatsi mieszkańcy ocic którzy nie mogli się pogodzić z faktem że ich spokojna dzielnica zmieniła sie w pobojowisko.</p>

                <p><a class="btn btn-outline-secondary" href="https://www.yiiframework.com/extensions/">Yii Extensions &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
